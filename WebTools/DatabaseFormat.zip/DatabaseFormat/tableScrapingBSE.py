import html5lib,requests
from bs4 import BeautifulSoup as soup
import random
import pandas as pd

def read_this (path):
	a=''
	f=open(path,'r',errors='ignore')
	a+=f.read()
	return a
def write_this (path,data):
	f=open(path,'a+',errors='ignore')
	f.write(data)

def open_page(url):
	headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
	fullText=requests.get(url,headers=headers).text
	return fullText

def get_tags(data,tag):
	soups=soup(data,features="html5lib")
	TAGS=soups.findAll(tag)
	list1=[i for i in TAGS]
	return list1

#We found their api url via inspect element in browser and using this url
#as the content is javascript loaded beautiful soup was not able to get the rendered view of page
urlForAjaxRequests='https://api.bseindia.com/BseIndiaAPI/api/shpSecSummery_New/w?qtrid=&scripcode=532488'
raw=open_page('https://api.bseindia.com/BseIndiaAPI/api/shpSecSummery_New/w?qtrid=&scripcode=532488')

tables=get_tags(raw,'table')
table=tables[3]
rows=table.findAll('tr')

dataBox=[]
for i in rows:
	td=i.findAll('td')
	if len(list(td))>0:
		dataBox.append([x.text for x in td ])

df = pd.DataFrame(dataBox[1:],columns=dataBox[0])
df.to_csv(r'BSE_Data1.csv',index=False)
pd.set_option("display.max_rows", None, "display.max_columns", None)
print(df)



