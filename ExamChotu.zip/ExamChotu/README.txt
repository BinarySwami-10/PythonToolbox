Disclaimer: 
i only wrote the code , its for educational purpose to aid you in writing exams and score good in bloody university exams.

License:
if you want to change the code and use it for different application, kindly remove my name then redistribute.

USAGE GUIDE:
YOU NEED TO KNOW BASIC HTML and CSS classes
Do not change the contents of the folder if you are not a programmer.
page.html contains the HTML markup. you need to manually add it by inspecting 
it in browser and copy the content of <body> tag and paste it in page.html file as google forms wont allow injection.

open page.html so that you will understand why. its the raw content of body tag.
For more instruction see the code. documentation is done in comments.
JUST run the examSolver.py file in CMD or powershell or BASH(linux).


IMPORTANT REQUIREMENTS:
install python 3.x
pip install selenium requests
pip install BeautifulSoup

you need firefox installed for this thing to work by default (as we used gecko driver which is a controller software for firefox browser)
or if you dont want  download chrome selenium driver and paste it in this folder.

Regards
-Nikhil Swami
